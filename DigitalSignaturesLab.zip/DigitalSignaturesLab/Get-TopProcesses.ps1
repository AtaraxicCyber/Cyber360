Write-Host "Analyzing system processes... please wait." -ForegroundColor Cyan

# Get processes, sort by specific property (WorkingSet), select top 5
$topProcesses = Get-Process | Sort-Object WorkingSet -Descending | Select-Object -First 5 Name, Id, WorkingSet

# Display the results in a table
$topProcesses | Format-Table -AutoSize

Write-Host "Analysis Complete."
# SIG # Begin signature block
# MIIFqgYJKoZIhvcNAQcCoIIFmzCCBZcCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCCjs6b1ASz3ztL
# DGwslWcsQAdD1vobK2W1/Y/TlUf9VKCCAyEwggMdMIICBaADAgECAhBJ5u2zIo6/
# jUedMXfcd/qWMA0GCSqGSIb3DQEBCwUAMBkxFzAVBgNVBAMMDkV4cGlyZWRMYWJD
# ZXJ0MB4XDTI1MTIwMjE2NDEwNFoXDTI1MTIwMjE2NTEyNFowGTEXMBUGA1UEAwwO
# RXhwaXJlZExhYkNlcnQwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDN
# 638cpmx5cgYUtuy3W6XC4PkK1WyO6l6uoJW0T8+o1HmQtNMyAU6kMHAB+cxIeHBX
# sCG7cV82nPYwky8GC7D4vfj9fXJ4u6vlyP7RFJUDomtKdX4xi9dB9VHnRcbOajP0
# /nJIVm7Fzg5d1gjZSAtOSbj54RvoaSyJ0et97ZtifdRcmz7kQIBgzGrJzG0iPUQG
# BK+gUTjY9oYGSdOzgp5UMizydLcYCM9la+uIQcC+fA0rRdnAXSICTCpIwzHXewk7
# 9N3kwxC19BdRZUSEvsJ8b20S9Pl/2P3SV6HVeKtgZWo+7ydCN+wSli9ioh0BN98M
# AMe9byrfwO28KMcjCVtxAgMBAAGjYTBfMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUE
# DDAKBggrBgEFBQcDAzAZBgNVHREEEjAQgg5FeHBpcmVkTGFiQ2VydDAdBgNVHQ4E
# FgQUHpt/7ru6MUiY+WwPplIneo0mBp4wDQYJKoZIhvcNAQELBQADggEBACfUwwCn
# I+p+Ub42wf49U7+nTkwEihLZvr1+MBuCXElH+eYQxWIG6au7qeavqImQrAU8mnT7
# BD0EeNjei1LkG2K2o3Vyt+SnG8bENytzWwtsQs3fDkwWH8DtMGJxERVDQgmb85KT
# PrFyQ3fNZ/yzenVvwo+cL1QauYg1zEmtUj0duGGtCOycVEMEg9xOFLItbuUQFtvn
# F1lr9ZP9D80gbUHUM3ZT9g+OmD0atQPn045ZPuO2nG9BROcmsaSN9o3NqKAFz8tn
# AlLLTp++90pNrSj3xEdsqq/Ti3x1/QbC0pyeThspCzDdSMNT9KAyDgxUFi7xP0e3
# 0BVnc7kDWn/wmjExggHfMIIB2wIBATAtMBkxFzAVBgNVBAMMDkV4cGlyZWRMYWJD
# ZXJ0AhBJ5u2zIo6/jUedMXfcd/qWMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQB
# gjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIOX5svxL
# HdZiDPtUVkN/4wWs31uK1r8nJjSHfzkAtQPpMA0GCSqGSIb3DQEBAQUABIIBAIVF
# FMzjWHQFqylloojrUD0HpsYQ1W2xGAp1wiS0k++tOzgy1dgWkbJ/NHlAum6X8gK0
# 6ev9tcSrdv+oUzSEeXXGeTaZYMlbfcBo5qAi0jvt4b3JtxDEcBQhBmCQsqipM9os
# SmgPX39xTe7ixuuF41N/xKrrrTf20WSEyf9yKkP8AJ0cgniRbGG5478zFiQhi7Tq
# /km0z+SdpkxgdNqkwvQ2oaa0dFecL+xsZkcvPz2t6W5giyohUP9dAytddn3nKBzh
# 382cxIiMwRzQQGdS+1Kpaokj2NcG0l9vXemibMH/IroblvnQjf+J/X1L7XMsww/N
# KdeAVESZ+fmPiOln+GQ=
# SIG # End signature block
